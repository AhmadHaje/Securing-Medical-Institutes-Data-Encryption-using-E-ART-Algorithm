package Fxml;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.cj.x.protobuf.MysqlxCrud.Collection;

import Home.AlertHelper;
import Home.E_ART;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.Window;

import Home.FileSystem;
import connectivity.ConnectionClass;

public class EncryptAllController {

	@FXML
	private TextField txtDirectory;

	@FXML
	private Button btnBack;

	@FXML
	private Button btnEncrypt;

	private Stage stage;

	private Scene scene;

	private Parent root;

	@FXML
	void Back(ActionEvent event) throws IOException {

		root = FXMLLoader.load(getClass().getResource("/Fxml/ManagerMainPage.fxml"));
		stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		stage.setTitle("Manager Main Page");
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();

	}

	@FXML
	void Encrypt(ActionEvent event) throws IOException, ClassNotFoundException, SQLException {
		if (txtDirectory.getText().equals("")) {
			Window owner = btnEncrypt.getScene().getWindow();
			AlertHelper.showAlert(Alert.AlertType.ERROR, owner, "Form Error!", "You must fill the field 'Directory'");
			return;
		}

		else {
			String path;
			String directory = txtDirectory.getText();
			ArrayList<String> list = new ArrayList<String>();
			// final File folder = new File(directory);

			// list = FileSystem.extractActionAll(directory);

			List<File> files = FileSystem.listf(directory);
			System.out.println(files.toString());

			for (int i = 0; i < files.size(); i++) {
				// path = list.get(i+1);

				path = files.get(i).getAbsolutePath();
				// System.out.println(path);

				String extension = "";

				int index = path.lastIndexOf('.');
				if (index > 0) {
					extension = path.substring(index + 1);
					//System.out.println(extension + "\n\n");
				}

				if (extension.equals("txt")) {
					// reading file content
					String info = FileSystem.extractFileEncryptAll(path);

					// delete file content
					File f = new File(path);
					PrintWriter writer = new PrintWriter(f);
					writer.print("");
					writer.close();

					/* encrypting info */

					String[] key=ConnectionClass.getNewKey();

					int N = Integer.parseInt(key[2].toString());
					int Variance = Integer.parseInt(key[3].toString());

					String encrypted_text = E_ART.encrypt(info, N, Variance);

					/* encrypting info */

					// writing back to file
					FileSystem mylogger = FileSystem.getInstance();
					// mylogger.initLogger();
					mylogger.insertInFile(path, encrypted_text);
				}

			}

			Window owner = btnEncrypt.getScene().getWindow();
			AlertHelper.showAlert(Alert.AlertType.CONFIRMATION, owner, "Done. ", "All Files Encrypted");

			// return back to manager main page
			root = FXMLLoader.load(getClass().getResource("/Fxml/ManagerMainPage.fxml"));
			stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setTitle("Manager Main Page");
			scene = new Scene(root);
			stage.setScene(scene);
			stage.show();

		}

	}

}
