package Fxml;

import java.io.IOException;

import Home.AlertHelper;
import connectivity.ConnectionClass;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.Window;

public class ManagerSignInPageController {

	@FXML
	private Pane frame;

	@FXML
	private Button btnBack;

	@FXML
	private TextField txtUserName;

	@FXML
	private TextField txtPassword;

	@FXML
	private Button btnLogIn;

	private Stage stage;

	private Scene scene;

	private Parent root;

	private String[] x;

	@FXML
	void Back(ActionEvent event) throws Exception {

		root = FXMLLoader.load(getClass().getResource("/Fxml/WelcomePage.fxml"));
		stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		stage.setTitle("Welcome Page");
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();

	}

	@FXML
	void LogIn(ActionEvent event) throws Exception {

		if (txtUserName.getText().equals("") || txtPassword.getText().equals("")) {
			Window owner = btnLogIn.getScene().getWindow();
			AlertHelper.showAlert(Alert.AlertType.ERROR, owner, "Form Error!", "You must fill all the fields");
			return;
		}

		else {

			String[] data = new String[2];
			data[0] = txtUserName.getText();
			data[1] = txtPassword.getText();

			x = ConnectionClass.ManagerCheckLogInData(data);

			if (x != null) {
				
				try {
					FXMLLoader loader=new FXMLLoader(getClass().getResource("/Fxml/ManagerMainPage.fxml"));
					root = (Parent)loader.load();
					
				
					stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
					stage.setScene(new Scene(root));
					stage.setTitle("Manager Main Page");
					stage.show();
					} catch (IOException e) {
						e.printStackTrace();
					}
				
			}

			else {
				Window owner = btnLogIn.getScene().getWindow();
				AlertHelper.showAlert(Alert.AlertType.ERROR, owner, "Form Error!", "Invaild Username OR Password");
				return;
			}

		}
	}

}