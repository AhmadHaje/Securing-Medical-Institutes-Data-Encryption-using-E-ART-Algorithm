package Fxml;

import java.io.IOException;
import java.sql.SQLException;

import Home.AlertHelper;
import Home.E_ART;
import Home.FileSystem;
import connectivity.ConnectionClass;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.Window;

public class NewFileController {

	@FXML
	private TextField txtID;

	@FXML
	private TextField txtTitle;

	@FXML
	private Button btnSave;

	@FXML
	private Button btnBack;

	@FXML
	 private TextArea txtInfo;

	private Stage stage;

	private Parent root;

	private int x;
	
	
	private String permission;
	

	@FXML
	void Back(ActionEvent event) throws IOException {
		
		
		try {
			FXMLLoader loader=new FXMLLoader(getClass().getResource("/Fxml/DoctorMainPage.fxml"));
			root = (Parent)loader.load();
			

			DoctorMainPageController main=loader.getController();
			main.getPermission(permission);
			
			
			stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Doctor Main Page");
			stage.show();
			} catch (IOException e) {
				e.printStackTrace();
			}
	}

	@FXML
	void Save(ActionEvent event) throws IOException, ClassNotFoundException, SQLException {

		if (txtID.getText().equals("") || txtInfo.getText().equals("") || txtTitle.getText().equals("")) {
			Window owner = btnSave.getScene().getWindow();
			AlertHelper.showAlert(Alert.AlertType.ERROR, owner, "Form Error!", "You must fill all the fields");
			return;
		}

		else

		{

			x = ConnectionClass.ExistPatient(txtID.getText());

			if (x == 1) {

				String Id = txtID.getText();
				String info = txtInfo.getText();
				String title = txtTitle.getText();

				/* encrypting info */
				
				String[] key=ConnectionClass.getNewKey();

				int N = Integer.parseInt(key[2].toString());
				int Variance = Integer.parseInt(key[3].toString());
				
				
				

				String encrypted_text = E_ART.encrypt(info, N, Variance);

				/* encrypting info */

				FileSystem mylogger = FileSystem.getInstance();
				// mylogger.initLogger();
				mylogger.insertAction(Id, encrypted_text, title);

				Window owner = btnSave.getScene().getWindow();
				AlertHelper.showAlert(Alert.AlertType.CONFIRMATION, owner, "Done. ", "patient info saved");
				return;

			}

			else {
				Window owner = btnSave.getScene().getWindow();
				AlertHelper.showAlert(Alert.AlertType.ERROR, owner, "Form Error!",
						"patient doesnt exist in the system, Add him before");
				return;
			}
		}

	}
	
	public void getPermission(String per) {
		permission=per;
	}

}
