package Fxml;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import java.io.IOException;

import javafx.event.ActionEvent;

public class ManagerMainPageController {

    @FXML
    private Button btnBack;

    @FXML
    private Button btnEncrypt;

    @FXML
    private Button btnChangeKeyValue;

    @FXML
    private Button btnSignOut;
    
    
	private Stage stage;

	private Scene scene;

	private Parent root;
	
	

    @FXML
    void Back(ActionEvent event) throws IOException {

		root = FXMLLoader.load(getClass().getResource("/Fxml/ManagerSignInPage.fxml"));
		stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		stage.setTitle("Manager Sign In Page");
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
    }
    
    @FXML
    void SignOut(ActionEvent event) throws IOException {

		root = FXMLLoader.load(getClass().getResource("/Fxml/ManagerSignInPage.fxml"));
		stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		stage.setTitle("Manager Sign In Page");
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();	
    }
    
    

    @FXML
    void ChangeKeyValue(ActionEvent event) throws IOException {
    	
		root = FXMLLoader.load(getClass().getResource("/Fxml/ChangeKeyValue.fxml"));
		stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		stage.setTitle("Change Key Value Page");
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
    }

    @FXML
    void Encrypt(ActionEvent event) throws IOException {
    	
		root = FXMLLoader.load(getClass().getResource("/Fxml/EncryptAllPage.fxml"));
		stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		stage.setTitle("Encrypt All Page");
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();

    }



}
