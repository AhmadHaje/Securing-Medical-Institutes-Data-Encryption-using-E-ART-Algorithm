package Fxml;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.io.IOException;

import Home.AlertHelper;
import javafx.event.ActionEvent;

public class DoctorMainPageController {

	@FXML
	private Button btnBack;

	@FXML
	private Button btnNewPatient;

	@FXML
	private Button btnSearch;

	@FXML
	private Button btnNewFile;

	@FXML
	private Button btnSignOut;

	private Stage stage;

	private Scene scene;

	private Parent root;
	
	
	
	private String permission;

	@FXML
	void Back(ActionEvent event) throws Exception {

		root = FXMLLoader.load(getClass().getResource("/Fxml/StaffSignInPage.fxml"));
		stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		stage.setTitle("Staff Sign In Page");
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();

	}

	@FXML
	void SignOut(ActionEvent event) throws Exception {
		root = FXMLLoader.load(getClass().getResource("/Fxml/StaffSignInPage.fxml"));
		stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		stage.setTitle("Staff Sign In Page");
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();

	}

	@FXML
	void NewPatient(ActionEvent event) throws Exception {

		try {
			FXMLLoader loader=new FXMLLoader(getClass().getResource("/Fxml/NewPatient.fxml"));
			root = (Parent)loader.load();
			

			NewPatientController main=loader.getController();
			main.getPermission(permission);
			
			
			stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("New Patient Page");
			stage.show();
			} catch (IOException e) {
				e.printStackTrace();
			}

	}

	@FXML
	void NewFile(ActionEvent event) throws Exception {
		
		
		try {
			FXMLLoader loader=new FXMLLoader(getClass().getResource("/Fxml/NewFile.fxml"));
			root = (Parent)loader.load();
			

			NewFileController main=loader.getController();
			main.getPermission(permission);
			
			
			stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("New File Page");
			stage.show();
			} catch (IOException e) {
				e.printStackTrace();
			}
		
		

	}

	@FXML
	void Search(ActionEvent event) throws Exception {
		
		//System.out.println("\n" + permission);
		
		if( permission.equals("A"))
		{
			try {
				FXMLLoader loader=new FXMLLoader(getClass().getResource("/Fxml/SearchPatient.fxml"));
				root = (Parent)loader.load();
				

				SearchPatientController main=loader.getController();
				main.getPermission(permission);
				
				
				stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
				stage.setScene(new Scene(root));
				stage.setTitle("Search Patient Page");
				stage.show();
				} catch (IOException e) {
					e.printStackTrace();
				}
		
		}
		else
		{
			Window owner = btnSearch.getScene().getWindow();
			AlertHelper.showAlert(Alert.AlertType.ERROR, owner, "Form Error!", "Sorry, you dont have a permission");
			return;
			
		}
	}
	
	public void getPermission(String per) {
		permission=per;
	}

}
