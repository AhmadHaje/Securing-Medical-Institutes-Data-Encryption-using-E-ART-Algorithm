package Fxml;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import Home.AlertHelper;
import Home.E_ART;
import Home.FileSystem;
import connectivity.ConnectionClass;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.Window;



public class AskedFileController {

	@FXML
	private Button btnBack;
	
    @FXML
    private Button btnEdit;

    @FXML
    private Button btnDelete;

	@FXML
	private TextArea txtInfo;

	private Stage stage;

	private Parent root;
	
	private String permission;
	
	private String Path,ID,Title;

	

	@FXML
	void Back(ActionEvent event) throws IOException {
		
		try {
			FXMLLoader loader=new FXMLLoader(getClass().getResource("/Fxml/SearchPatient.fxml"));
			root = (Parent)loader.load();
			

			//System.out.println("\n\n"+ permission + "\n\n");
			
			SearchPatientController ask=loader.getController();
			ask.getPermission(permission);
			
			
			stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Search Patient Page");
			stage.show();
			} catch (IOException e) {
				e.printStackTrace();
			}
		

	}
	
	
	@FXML
    void Delete(ActionEvent event) {

		try  
		{         
		File f= new File(Path);           //file to be delete  
		if(f.delete())                      //returns Boolean value  
		{  
		System.out.println(f.getName() + " deleted");   //getting and printing the file name 
		Window owner = btnDelete.getScene().getWindow();
		AlertHelper.showAlert(Alert.AlertType.CONFIRMATION, owner, "Done. ", "File deleted successfully");
		}  
		else  
		{  
		System.out.println("failed");
		Window owner = btnDelete.getScene().getWindow();
		AlertHelper.showAlert(Alert.AlertType.ERROR, owner, "Form Error!", "Cant delete this file");
		}  
		}  
		catch(Exception e)  
		{  
		e.printStackTrace();  
		}  
		
		
		//return Back after deleting
		try {
			FXMLLoader loader=new FXMLLoader(getClass().getResource("/Fxml/SearchPatient.fxml"));
			root = (Parent)loader.load();
			

			//System.out.println("\n\n"+ permission + "\n\n");
			
			SearchPatientController ask=loader.getController();
			ask.getPermission(permission);
			
			
			stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Search Patient Page");
			stage.show();
			} catch (IOException e) {
				e.printStackTrace();
			}
		
    }

    @FXML
    void Edit(ActionEvent event) throws IOException, ClassNotFoundException, SQLException {

		if (txtInfo.getText().equals("")) {
			Window owner = btnEdit.getScene().getWindow();
			AlertHelper.showAlert(Alert.AlertType.ERROR, owner, "Form Error!", "You must fill the field");
			return;
		}

		else

		{
			
			//delete file content
			File f= new File(Path); 
			PrintWriter writer = new PrintWriter(f);
			writer.print("");
			writer.close();

				String info = txtInfo.getText();

				/* encrypting info */

				String[] key=ConnectionClass.getNewKey();

				int N = Integer.parseInt(key[2].toString());
				int Variance = Integer.parseInt(key[3].toString());

				String encrypted_text = E_ART.encrypt(info, N, Variance);

				/* encrypting info */

				FileSystem mylogger = FileSystem.getInstance();
				// mylogger.initLogger();
				mylogger.insertInFile(Path, encrypted_text);

				Window owner = btnEdit.getScene().getWindow();
				AlertHelper.showAlert(Alert.AlertType.CONFIRMATION, owner, "Done. ", "Edit saved");
				return;

			}


		}


	
    

public void getID(String id) {
	ID=id;
}

public void getTitle(String title) {
	Title=title;
}

    public void getPath(String path) {
		Path=path;
	}
    
	public void getText(String info) {
		txtInfo.setText(info);
	}

	public void getPermission(String per) {
		permission=per;
	}
}
