package Fxml;

import java.io.IOException;
import Home.AlertHelper;
import Home.FileSystem;
import connectivity.ConnectionClass;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.Window;

public class NewPatientController {

	@FXML
	private TextField txtFirstName;

	@FXML
	private TextField txtLastName;

	@FXML
	private TextField txtID;

	@FXML
	private Button btnSave;

	@FXML
	private Button btnBack;

	private Stage stage;

	private Parent root;
	
	private String permission;

	@FXML
	void Back(ActionEvent event) throws IOException {

		try {
			FXMLLoader loader=new FXMLLoader(getClass().getResource("/Fxml/DoctorMainPage.fxml"));
			root = (Parent)loader.load();
			

			DoctorMainPageController main=loader.getController();
			main.getPermission(permission);
			
			
			stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Doctor Main Page");
			stage.show();
			} catch (IOException e) {
				e.printStackTrace();
			}

	}

	@FXML
	void Save(ActionEvent event) throws IOException {

		if (txtFirstName.getText().equals("") || txtLastName.getText().equals("") || txtID.getText().equals("")) {
			Window owner = btnSave.getScene().getWindow();
			AlertHelper.showAlert(Alert.AlertType.ERROR, owner, "Form Error!", "You must fill all the fields");
			return;
		}

		else {

			String[] data = new String[3];
			data[0] = txtFirstName.getText();
			data[1] = txtLastName.getText();
			data[2] = txtID.getText();

			int x = ConnectionClass.InsertPatientData(data);

			FileSystem mylogger = FileSystem.getInstance();
			mylogger.initLogger(data[2]);

			if (x == 1) {
				Window owner = btnSave.getScene().getWindow();
				AlertHelper.showAlert(Alert.AlertType.CONFIRMATION, owner, "Done. ", "patient data saved");
				return;
			}

		}

	}

	public void getPermission(String per) {
		permission=per;
	}
}
