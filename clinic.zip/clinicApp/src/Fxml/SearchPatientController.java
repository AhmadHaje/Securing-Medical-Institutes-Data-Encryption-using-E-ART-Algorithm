package Fxml;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.Scanner;

import Home.AlertHelper;
import Home.E_ART;
import Home.FileSystem;
import Home.PatientFile;
import connectivity.ConnectionClass;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import javafx.stage.Window;

public class SearchPatientController implements Initializable {

	@FXML
	private TextField txtID;

	@FXML
	private Button btnSearch;

	@FXML
	private Button btnBack;
	
	@FXML
	private Button btnOpen;

	@FXML
	private TableView<PatientFile> FilesTable;

	@FXML
	private TableColumn<PatientFile, String> FileName;

	@FXML
	private TableColumn<PatientFile, String> FileDate;

	private Stage stage;

	private Parent root;

	private String info;

	private String permission;

	ObservableList<PatientFile> List = FXCollections.observableArrayList();

	@FXML
	void Back(ActionEvent event) throws IOException {

		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/Fxml/DoctorMainPage.fxml"));
			root = (Parent) loader.load();

			DoctorMainPageController main = loader.getController();
			main.getPermission(permission);

			stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Doctor Main Page");
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@FXML
	void Search(ActionEvent event) throws IOException {

		ArrayList<String> res;

		if (txtID.getText().equals("")) {
			Window owner = btnSearch.getScene().getWindow();
			AlertHelper.showAlert(Alert.AlertType.ERROR, owner, "Form Error!", "You must fill all the fields");
			return;
		}

		else {
			FileSystem mylogger = FileSystem.getInstance();
			res = mylogger.extractAction(txtID.getText());

			if (res == null) {
				Window owner = btnSearch.getScene().getWindow();
				AlertHelper.showAlert(Alert.AlertType.ERROR, owner, "Form Error!", "Invalid Id OR Title");
				return;
			} else {

				// Initialize PatientFile ObserveList
				PatientFile p;

				int i = 0;

				FilesTable.getItems().clear();

				while (res.size() > i) {
					// action
					p = new PatientFile(res.get(i), "1-1-2020");

					i++;

					List = FilesTable.getItems();
					List.add(p);
					FilesTable.setItems(List);
				}

			}

		}

	}
	
	
	

	@FXML
	void Open(ActionEvent event) throws IOException, ClassNotFoundException, SQLException {

		String title;
		
		List=FilesTable.getSelectionModel().getSelectedItems();
		title=List.get(0).getFileName();
		
		
		//System.out.println("\n\n"+ title);
		
		String res;


			FileSystem mylogger = FileSystem.getInstance();
			res = mylogger.extractFile(txtID.getText(), title);

			if (res == "") {
				Window owner = btnOpen.getScene().getWindow();
				AlertHelper.showAlert(Alert.AlertType.ERROR, owner, "Form Error!", "Invalid Id OR Title");
				return;
			} else {


				/* decrypting res */
				String[] key=ConnectionClass.getNewKey();

				int N = Integer.parseInt(key[2].toString());
				int Variance = Integer.parseInt(key[3].toString());
				
				info = E_ART.decrypt(res, N, Variance);

				/* decrypting res */
				
				
				try {
				FXMLLoader loader=new FXMLLoader(getClass().getResource("/Fxml/AskedFile.fxml"));
				root = (Parent)loader.load();
				

				AskedFileController ask=loader.getController();
				
				
				StringBuilder str = new StringBuilder();
				int i,x;
				for (i=0; i<info.length();i++) 
				{
				x=info.charAt(i);
				if(x==127)
					str.append(" ");
				else
					str.append(info.charAt(i));
				}
				System.out.print(str);
				
				info= str.toString();
				ask.getText(info);
				
				 ask=loader.getController();
				ask.getPermission(info);
				
				
				ask.getPath("c:\\wael\\clinic\\" + txtID.getText() + "\\" + title);
				
				ask.getID(txtID.getText());
				
				ask.getTitle(title);
				
				
				stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
				stage.setScene(new Scene(root));
				stage.setTitle("Asked File Page");
				stage.show();
				} catch (IOException e) {
					e.printStackTrace();
				}

				
			}

		}

	
	
	public void getPermission(String per) {
		permission=per;
	}




	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		FileName.setCellValueFactory(new PropertyValueFactory<PatientFile, String>("FileName"));
		FileDate.setCellValueFactory(new PropertyValueFactory<PatientFile, String>("FileDate"));

		FilesTable.setItems(List);

	}

}
