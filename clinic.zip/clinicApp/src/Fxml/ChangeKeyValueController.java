package Fxml;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import Home.AlertHelper;
import Home.E_ART;
import Home.FileSystem;
import connectivity.ConnectionClass;
import javafx.event.ActionEvent;

public class ChangeKeyValueController {

    @FXML
    private TextField txtN;

    @FXML
    private Button btnSave;

    @FXML
    private Button btnBack;

    @FXML
    private TextField txtVariance;
    
    
	private Stage stage;

	private Scene scene;

	private Parent root;
	

    @FXML
    void Back(ActionEvent event) throws IOException {
    	
		root = FXMLLoader.load(getClass().getResource("/Fxml/ManagerMainPage.fxml"));
		stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		stage.setTitle("Manager Sign In Page");
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();

    }

    @FXML
    void Save(ActionEvent event) throws ClassNotFoundException, SQLException, IOException {
    	
    	if (txtN.getText().equals("") || txtVariance.getText().equals("")) {
			Window owner = btnSave.getScene().getWindow();
			AlertHelper.showAlert(Alert.AlertType.ERROR, owner, "Form Error!", "You must fill all the fields");
			return;
		}
    	
    	else {

    		int N,Variance;
    		
			String[] dataNew = new String[2];
			dataNew[0] = txtN.getText();
			dataNew[1] = txtVariance.getText();
			
			String[] dataOld = new String[2];
			
			N=Integer.parseInt(txtN.getText());
			Variance=Integer.parseInt(txtVariance.getText());
			
			//get the key values before update
			String[] keyOld=ConnectionClass.getNewKey();
			
			dataOld[0] = keyOld[2].toString();
			dataOld[1] = keyOld[3].toString();
			
			int NOld = Integer.parseInt(keyOld[2].toString());
			int VarianceOld = Integer.parseInt(keyOld[3].toString());
			
			

			int x = ConnectionClass.changeNewKeyValue(dataNew);
			
			int y=ConnectionClass.changeOldKeyValue(dataOld);
			
			
			//move on every file in directory
			
			String path;
			String directory = ("C:\\wael\\clinic");
			
			List<File> files = FileSystem.listf(directory);
			System.out.println(files.toString());

			for (int i = 0; i < files.size(); i++) {

				path = files.get(i).getAbsolutePath();

				
				String extension = "";
				int index = path.lastIndexOf('.');
				if (index > 0) {
					extension = path.substring(index + 1);
					//System.out.println(extension + "\n\n");
				}

				if (extension.equals("txt")) {
					// reading file content
					String info = FileSystem.extractFileEncryptAll(path);

					// delete file content
					File f = new File(path);
					PrintWriter writer = new PrintWriter(f);
					writer.print("");
					writer.close();

					/* decrypting info with Old keys*/

					String decrypted_text = E_ART.decrypt(info, NOld, VarianceOld);

					/* encrypting info with new keys*/
					
					String encrypted_text = E_ART.encrypt(decrypted_text, N, Variance);

					// writing back to file
					FileSystem mylogger = FileSystem.getInstance();
					// mylogger.initLogger();
					mylogger.insertInFile(path, encrypted_text);
				}

			}
			
			

			if ((x == 1)&&(y == 1)) {
				Window owner = btnSave.getScene().getWindow();
				AlertHelper.showAlert(Alert.AlertType.CONFIRMATION, owner, "Done. ", "Key Values Changed");
				return;
			}
			
			
			
			//return back to main page
			root = FXMLLoader.load(getClass().getResource("/Fxml/ManagerMainPage.fxml"));
			stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setTitle("Manager Sign In Page");
			scene = new Scene(root);
			stage.setScene(scene);
			stage.show();

    }

}
}
