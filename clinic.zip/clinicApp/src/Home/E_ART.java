package Home;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class E_ART {
	
	static int Len_max = 127;
	static int Offset_const = 32;
	static int R = 64;
	
	//private int N = 626;
	//private int Variance = 99;

	public static String encrypt(String input_text, int N, int Variance) {
		// 1111111111111111111111111111111
		// 2
		List<Character> input_list = new ArrayList<Character>();
		// 3
		int asci;
		List<Integer> Val_org_list = new ArrayList<Integer>();
		// 4
		int N_L;
		int N_R;
		int Offset_var;
		// 5
		int j;
		// 6
		List<Integer> word = new ArrayList<Integer>();
		// 8
		int Val_initial_ref;
		int Val_org;
		// 9
		int Dynamic_offset;
		Random r = new Random();

		int Pseudo;
		// 10
		int x;
		// 11-15
		int Val_ref;
		List<Integer> Val_ref_list = new ArrayList<Integer>();
		// 17
		int Ch_value;
		List<Integer> EncryptedWord = new ArrayList<Integer>();
		// 18
		List<Character> encrypted_list = new ArrayList<Character>();

		// 22222222222222222222

		char[] cArray = input_text.toCharArray();
		for (int i = 0; i < input_text.length(); i++) {
			input_list.add(cArray[i]);
		}
		

		// 33333333333333333333
		while (!input_list.isEmpty()) {
			char ch = input_list.remove(0);
			asci = (int) ch;

			Val_org_list.add(asci);
		}
		


		// 44444444444444444444
		N_L = N % Len_max;
		N_R = (Len_max - N_L) - 1;

		if (N_L < R)
			Offset_var = (R * N_L) % N_R;
		else
			Offset_var = (R * N_R) % N_L;
		
		
		//System.out.println("Offset_var is " + Offset_var);

		// 55555555555555555555
		j = 0;
		while (!Val_org_list.isEmpty()) {
			asci = 1;
			int wordlength = 0;

			// 66666666666666666666
			while ((asci != 32) && (!Val_org_list.isEmpty())) {
				asci = Val_org_list.remove(0);
				word.add(asci);
				wordlength++;
			}
			
			//System.out.println("word is " + word);
			

			// 77777777777777777777
			for (int i = 0; i < wordlength; i++) {

				// 88888888888888888888
				Val_org = word.remove(0);

				Val_initial_ref = (Len_max - Val_org) + 1;
				
				
				//System.out.println("Val_initial_ref is " + Val_initial_ref + " "+  j); 

				// 99999999999999999999
				long s = j;
				r.setSeed(s);
				Pseudo = r.nextInt();
				

				Dynamic_offset = Pseudo % Variance;
				if (Dynamic_offset<0)
					Dynamic_offset+=Variance;
				
				//System.out.println("Dynamic_offset is " + Dynamic_offset + " "+  j);
				
				
				j++;

				// 10 10 10 10 10 10 10
				x = Val_initial_ref + Offset_var + Offset_const;

				// 11 11 11-15 15 15 15
				if (x > Len_max) {
					////////////////+ Offset_const
					Val_ref = ((x % Len_max)  + Dynamic_offset + Offset_const);
				} else {
					Val_ref = x + Dynamic_offset;
				}
				
				
				
				

				// 16 16 16 16 16 16 16
				Val_ref_list.add(Val_ref);

			}
			
			

			// 17 17 17 17 17 17 17
			while (!Val_ref_list.isEmpty()) {
				Ch_value = Val_ref_list.remove(0);
				EncryptedWord.add(Ch_value);
				
			}
			
			//System.out.println("EncryptedWord is " + EncryptedWord);

			// 18 18 18 18 18 18 18
			while (!EncryptedWord.isEmpty()) {
				asci = EncryptedWord.remove(0);
				char ch = (char) asci;
				encrypted_list.add(ch);
			}
			
			

			// 20 20 20 20 20 20 20
		}

		// 21 21 21 21 21 21 21

		//System.out.println(encrypted_list);
		//System.out.println("\n\n");
		

		String result = "";

		while (!encrypted_list.isEmpty())
			result += encrypted_list.remove(0);

		return result;
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public static String decrypt(String encrypted_text, int N, int Variance) {
		// 111111111111111111111
		// 2
		List<Character> input_list = new ArrayList<Character>();
		// 3
		char ch;
		int asci;
		List<Integer> Val_org_list = new ArrayList<Integer>();
		// 4
		int N_L;
		int N_R;
		int Offset_var;
		// 5
		int wordlength;
		// 6
		List<Integer> word = new ArrayList<Integer>();
		int j;

		// 7
		int Val_org;
		// 8
		int Dynamic_offset;
		Random r = new Random();
		int Pseudo;
		// 9
		int x;
		// 10-13
		int y;
		// 14
		int Val_ref;
		// 15
		int decrypted_value;
		// 17
		List<Integer> decrypted_value_list = new ArrayList<Integer>();
		// 18
		int Ch_value;
		List<Integer> decryptedWord = new ArrayList<Integer>();
		// 19
		List<Character> decrypted_list = new ArrayList<Character>();

		// 22222222222222222222
		char[] cArray = encrypted_text.toCharArray();
		for (int i = 0; i < encrypted_text.length(); i++) {
			input_list.add(cArray[i]);
		}
		//System.out.println(input_list);

		// 33333333333333333333

		while (!input_list.isEmpty()) {
			ch = input_list.remove(0);
			asci = (int) ch;

			Val_org_list.add(asci);
			
		}
		
		
		
		//System.out.println("Val_org_list is " + Val_org_list );

		// 44444444444444444444

		N_L = N % Len_max;
		N_R = (Len_max - N_L) - 1;

		if (N_L < R)
			Offset_var = (R * N_L) % N_R;
		else
			Offset_var = (R * N_R) % N_L;
		
		
		
		
		
		

		// 55555555555555555555

		j = 0;

		while (!Val_org_list.isEmpty()) {
			asci = 1;
			wordlength = 0;

			// 66666666666666666666

			while ((asci != 32) && (!Val_org_list.isEmpty())) {
				asci = Val_org_list.remove(0);
				word.add(asci);
				wordlength++;
			}
			
			
			

			// 77777777777777777777

			for (int i = 0; i < wordlength; i++) {

				Val_org = word.remove(0);

				// 88888888888888888888

				long s = j;
				r.setSeed(s);
				Pseudo = r.nextInt();
				j++;
				Dynamic_offset = Pseudo % Variance;
				if (Dynamic_offset<0)
					Dynamic_offset+=Variance;
				
			

				// 99999999999999999999

				x = Val_org - Dynamic_offset;
				
				

				// 10 10 10 - 13 13 13
				
				y= x - Offset_var - Offset_const;

				if (y < 0)
					//- Offset_const
					Val_ref = Len_max  + y - Offset_const;
				else
					Val_ref =  y;

				// 14 14 14 14 14 14 14

				

				// 15 15 15 15 15 15 15

				decrypted_value = (Len_max - Val_ref) + 1;
				
				

				// 16 16 16 16 16 16 16

				// 17 17 17 17 17 17 17

				decrypted_value_list.add(decrypted_value);

			}
			
			

			// 18 18 18 18 18 18 18

			while (!decrypted_value_list.isEmpty()) {
				Ch_value = decrypted_value_list.remove(0);
				decryptedWord.add(Ch_value);

			}
			
			
			//System.out.println(decryptedWord);
			

			// 19 19 19 19 19 19 19

			while (!decryptedWord.isEmpty()) {
				asci = decryptedWord.remove(0);

					ch = (char) asci;
				
				
				decrypted_list.add(ch);
			}
			
			
			
			
			// 20 20 20 20 20 20 20
		}
		// 21 21 21 21 21 21 21
		
		

		//System.out.println(decrypted_list);
		//System.out.println("\n\n");
		// System.out.format("%d%n",asci);

		String result = "";

		while (!decrypted_list.isEmpty())
			result += decrypted_list.remove(0);

		return result;

	}
	
	/*
	public static void main(String[] args) throws IOException {
		

		
		String text1="wael hamada";
		
		//String text2="waalhamada";
		
		System.out.println("text1 is: " +text1);
		//System.out.println("text2 is: " +text2);


		int N = 626;
		int Variance = 99;

		String encrypted_text1 = E_ART.encrypt(R, Offset_const, Len_max, text1, N, Variance);
		
		System.out.println("encrypted_text1 is: " +encrypted_text1);
		
        //String encrypted_text2 = E_ART.encrypt(R, Offset_const, Len_max, text2, N, Variance);
		
		//System.out.println("encrypted_text2 is: " +encrypted_text2);



		String decrypted1 = E_ART.decrypt(R, Offset_const, Len_max, encrypted_text1, N, Variance);
		
		System.out.println("decrypted1 is: " +decrypted1);
		
        //String decrypted2 = E_ART.decrypt(R, Offset_const, Len_max, encrypted_text2, N, Variance);
		
		//System.out.println("decrypted2 is: " +decrypted2);
		

	}
*/
	
}
