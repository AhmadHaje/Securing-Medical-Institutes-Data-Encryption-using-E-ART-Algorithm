package Home;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;




public class FileSystem {

	static FileSystem _instance = null;
	String firstfileName = "c:\\wael\\clinic";



	public FileSystem() {
		//System.out.println("Constructor logger");
	}

	public static FileSystem getInstance() {
		if (_instance == null) {
			//System.out.println("new logger");
			_instance = new FileSystem();
		}
		return _instance;
	}

	public void initLogger(String patientID) throws IOException {
		/*
		 * try { String fileName= ( firstfileName + "\\" + patientID + ".mkdir"); File
		 * myObj = new File(fileName); if (myObj.createNewFile()) {
		 * System.out.println("File created: " + myObj.getName()); } else {
		 * System.out.println("File already exists."); } } catch (IOException e) {
		 * System.out.println("An error occurred."); e.printStackTrace(); }
		 */

		String path = (firstfileName + "\\" + patientID);
		File f1 = new File(path);
		// Creating a folder using mkdir() method
		boolean bool = f1.mkdir();
		if (bool) {
			System.out.println("Folder is created successfully");
		} else {
			System.out.println("Error Found!");
		}
	}

	public void insertAction(String patientID, String encryptedText, String title) throws IOException {

		String fileName = (firstfileName + "\\" + patientID + "\\" + title + ".txt");
		//System.out.println(fileName);

		/*
		FileWriter writer = new FileWriter(fileName, true);
		StringBuilder sb = new StringBuilder();
		sb.append(encryptedText);
		writer.write(sb.toString());
		writer.close();
		*/
		
		// writing
		try (BufferedWriter wr = Files.newBufferedWriter(Paths.get(fileName), StandardCharsets.UTF_8)) {

			byte[] bytes = encryptedText.getBytes(StandardCharsets.UTF_8);

			String string = new String(bytes, StandardCharsets.UTF_8);

			//System.out.println(string);

			wr.write(string);
		}
		
	}
	
	public void insertInFile(String path, String encryptedText) throws IOException {

		String fileName = (path);
		
		// writing
		try (BufferedWriter wr = Files.newBufferedWriter(Paths.get(fileName), StandardCharsets.UTF_8)) {

			byte[] bytes = encryptedText.getBytes(StandardCharsets.UTF_8);

			String string = new String(bytes, StandardCharsets.UTF_8);

			//System.out.println(string);

			wr.write(string);
		}
		
	}
	
	
	
	public String extractFile(String patientID, String title) throws IOException {

		String data="";
		String fileName = (firstfileName + "\\" + patientID + "\\" + title );
		//System.out.println(fileName);

		
		
		// reading
		try {
			File myObj = new File(fileName);
			// Scanner myReader = new Scanner(myObj);
			Scanner myReader = new Scanner(new InputStreamReader(new FileInputStream(fileName),
					StandardCharsets.UTF_8));
			while (myReader.hasNextLine()) {
				data = myReader.nextLine();

			}

			myReader.close();
		} catch (FileNotFoundException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
    
    
		 return data;
		 
		 
		  }
	
	
	public static String extractFileEncryptAll(String path) throws IOException {

		String data="";
		//System.out.println(path);


		// reading
		try {
			File myObj = new File(path);
			// Scanner myReader = new Scanner(myObj);
			Scanner myReader = new Scanner(new InputStreamReader(new FileInputStream(path),
					StandardCharsets.UTF_8));
			while (myReader.hasNextLine()) {
				data = myReader.nextLine();

			}

			myReader.close();
		} catch (FileNotFoundException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
    
		 return data;
		 	 
		  }
	
	
	
	
	
	
	
	
	
	
	
	
	
	public ArrayList<String> extractAction(String patientID) throws IOException {

		ArrayList<String> list = new ArrayList<String>();

		
		String fileName = (firstfileName + "\\" + patientID );
		
		
		final File folder = new File(fileName);
		
		
		list=listFilesForFolder(folder);

		return list;

		
		  }
	
	
	
	
	
	
	public static ArrayList<String> listFilesForFolder(final File folder) {
		
		ArrayList<String> list = new ArrayList<String>();
		
		for (final File fileEntry : folder.listFiles()) {
			if (fileEntry.isDirectory()) {
				listFilesForFolder(fileEntry);
			} else {
				list.add(fileEntry.getName());
				//System.out.println(fileEntry.getName());
			}
		}
		
		return list;


	}
	
	
	public static ArrayList<String> extractActionAll(String directory) throws IOException {

		ArrayList<String> list = new ArrayList<String>();
		
		final File folder = new File(directory);
			
		list=listFilesForFolderAllDirectory(folder);

		return list;

		
		  }
	
	
	
	
	
    public static List<File> listf(String directoryName) {
        File directory = new File(directoryName);

        List<File> resultList = new ArrayList<File>();

        // get all the files from a directory
        File[] fList = directory.listFiles();
        resultList.addAll(Arrays.asList(fList));
        for (File file : fList) {
            if (file.isFile()) {
                System.out.println(file.getAbsolutePath());
            } else if (file.isDirectory()) {
                resultList.addAll(listf(file.getAbsolutePath()));
            }
        }
        //System.out.println(fList);
        return resultList;
    }
	
	
	

	
	
	
public static ArrayList<String> listFilesForFolderAllDirectory(final File folder) {
		
		ArrayList<String> list = new ArrayList<String>();
		
		for (final File fileEntry : folder.listFiles()) {
			if (fileEntry.isDirectory()) {
				listFilesForFolder(fileEntry);
			} else {
				list.add(fileEntry.getName());
				list.add(fileEntry.getAbsolutePath());
				//System.out.println(fileEntry.getName());
			}
		}
		
		return list;


	}
	
	
	


}
